var searchData=
[
  ['name_25',['Name',['../className.html',1,'Name'],['../className.html#af3848e4d75a26aaac3b04d75573b5144',1,'Name::Name()']]]
];
